#max heap for rrt_star nearest nodes
import math

class HeapItem:
    def __init__(self,node,data):
        self.node = node
        self.data = data

class MaxHeap:
    def __init__(self):
        self.items = []
        self.size = 0
    
    def pop(self): 
        #print('popping')
        max = self.items[0]
        self.items[0] = self.items[self.size-1]
        self.items.pop(self.size-1)
        self.size = self.size-1
        self.heapifyDown()
        return max;
    
    def peek(self): 
        #print('peeking')
        return self.items[0];
    
    def add(self, a):
        #print('adding')
        self.items.append(a)
        self.size = self.size+1
        self.heapifyUp(self.size-1);
    
    def heapifyDown(self):
        if self.size < 2:
                return;
        else:
            #print('heapifydown')
            i = 0;
            while i*2+1<self.size:
                #print('in heapifydown')
                biggerChildIndex = 2*i+1;
                if 2*i+2 < self.size and self.items[2*i+1].data<self.items[2*i+2].data:
                    biggerChildIndex = 2*i+2;
                if self.items[i].data < self.items[biggerChildIndex].data:
                    temp = self.items[i]
                    self.items[i] = self.items[biggerChildIndex]
                    self.items[biggerChildIndex] = temp
                    i = biggerChildIndex
                else:
                    break
    
    def heapifyUp(self, index):
            if self.size<2:
                return;
            else:
                #print('heapifyup')
                i = index;
                while math.floor((i-1)/2)>=0:
                    #print('in heapifyup')
                    if i%2 == 0 and i!=0 and self.items[i].data <= self.items[i-1].data:
                        break;
                    if self.items[i].data <= self.items[math.floor((i-1)/2)].data:
                        break;
                    else:
                        if i!=0 and self.items[i].data > self.items[math.floor((i-1)/2)].data:
                            temp = self.items[i]
                            self.items[i] = self.items[math.floor((i-1)/2)]
                            self.items[math.floor((i-1)/2)] = temp
                            i = math.floor((i-1)/2)

#def main():
#    heap = MaxHeap()
#    heap.add(HeapItem(None,2))
#    heap.add(HeapItem(None,4))
#    heap.add(HeapItem(None,3))
#    heap.add(HeapItem(None,8))
#    heap.add(HeapItem(None,2))
#    while heap.size>0:
#        print(heap.pop().data)
#
#if __name__ == '__main__':
#    main()