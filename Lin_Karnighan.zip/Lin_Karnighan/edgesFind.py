import random
from math import *
from pygame import *
import geometry,pathFind #prm
#import rrt_connect_new_edgefind

#path between 2 points

def dist(p1,p2):     #distance between two points
    return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))
    
def lineIntersect(p1,p2,rectObs,circleObs):
    #print('line intersect checking')
    for rect in rectObs:
        r1 = (rect.center[0]+rect.width/2, rect.center[1]+rect.height/2)
        r2 = (rect.center[0]-rect.width/2, rect.center[1]-rect.height/2)
        r3 = (rect.center[0]-rect.width/2, rect.center[1]+rect.height/2)
        r4 = (rect.center[0]+rect.width/2, rect.center[1]-rect.height/2)
        if ((p2[0]-p1[0])*r1[1] + (p1[1]-p2[1])*r1[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r2[1] + (p1[1]-p2[1])*r2[0] - p2[0]*p1[1] + p1[0]*p2[1])<0 or ((p2[0]-p1[0])*r3[1] + (p1[1]-p2[1])*r3[0] - p2[0]*p1[1] + p1[0]*p2[1])*((p2[0]-p1[0])*r4[1] + (p1[1]-p2[1])*r4[0] - p2[0]*p1[1] + p1[0]*p2[1])<=0:
            #if this is true there has to be 1 more check
            if ((r2[0]-r1[0])*p1[1] + (r1[1]-r2[1])*p1[0] - r2[0]*r1[1] + r1[0]*r2[1])*((r2[0]-r1[0])*p2[1] + (r1[1]-r2[1])*p2[0] - r2[0]*r1[1] + r1[0]*r2[1])<0 or ((r4[0]-r3[0])*p1[1] + (r3[1]-r4[1])*p1[0] - r4[0]*r3[1] + r3[0]*r4[1])*((r4[0]-r3[0])*p2[1] + (r3[1]-r4[1])*p2[0] - r4[0]*r3[1] + r3[0]*r4[1])<=0:
                return True
    for circle in circleObs:
        centerx = circle[0]
        centery = circle[1]
        if abs((p2[0]-p1[0])*centery + (p1[1]-p2[1])*centerx - p2[0]*p1[1] + p1[0]*p2[1])<=circle[2]*sqrt((p2[0]-p1[0])*(p2[0]-p1[0])+(p1[1]-p2[1])*(p1[1]-p2[1])):
            return True
    return False

def findEdge(vertices,allEdges,rectObs,circleObs,width,height):
    print('finding edges')
    i=0
    while i<len(vertices)-1:
        j=i+1
        while j<len(vertices):
            if lineIntersect(vertices[i].point,vertices[j].point,rectObs,circleObs) == False:
                print('no obstacles')
                allEdges[str(vertices[i].vId)+'-'+str(vertices[j].vId)] = geometry.Edge(vertices[i],vertices[j],[vertices[i].point,vertices[j].point])
            else:
                print('obstacles, do aco')
                #do pathFind for these 2 points
                #addEdge
                allEdges[str(vertices[i].vId)+'-'+str(vertices[j].vId)] = pathFind.main(vertices[i],vertices[j],rectObs,circleObs,width,height)
            j=j+1
        i=i+1    
