from math import *
import ant, geometry

def main(v1,v2,rectObs,circleObs,XDIM,YDIM):
    GOAL_RADIUS = 10
    minImprovement = 0.01 #1%
    numIter = 5
    percentPherReduced = 0.3
    gridscale = 10
    pheromoneTrack = []
    #array of vector - vector appears equal to numofants who went there*10(pherValue)
    antPopnIter = 0
    maxAntPopnIter = 10 #50
    antPopnSize = 10 #50
    antPopn = []
    recordAnt = None
    
    initialPoint = v1.point
    goalPoint = v2.point
    antsReached = 0
    lastBestPath = 0
    antsDone = {}
    optimiseIter = 0
    currentState = 'findPath'

    i=0
    while i<floor(XDIM/gridscale):
        pheromoneTrack.append([])
        j=0
        while j<floor(YDIM/gridscale):
            pheromoneTrack[i].append([])
            j = j+1
        i=i+1
    i=0
    while i<antPopnSize:
        antPopn.append(ant.Ant(i,initialPoint))
        i = i+1
    while True: 
        
        if currentState == 'findPath':
            t=0
            while t<len(pheromoneTrack):
                #print('pher evaporating')
                phTrk = pheromoneTrack[t]
                u = 0
                while u<len(phTrk):
                    phT = phTrk[u]
                    i=0
                    #at each point it goes down by percentPherReduced (0.3 here)
                    while i<len(phT)-1:
                        #print('e')
                        j=i
                        count = 0
                        while j<len(phT)-1 and phT[j][0] == phT[j+1][0] and phT[j][1] == phT[j+1][1]:
                            #print('f')
                            count = count+1
                            j = j+1
                        #print('count: ' + str(count))
                        k = 0
                        while k<floor(count*percentPherReduced)+1:
                            #print('g')
                            phT.pop(i)
                            k = k+1
                        i = i+count-k+1
                    u = u+1
                t = t+1
            
            for a in antPopn:
                if a.reachedGoal == True: 
                    if a.ID not in antsDone: #ie reached now - we can do dist check too so can exit if that not true anyway
                        print('this ant reached')
                        #antsDone.append(a.ID)
                        antsDone[a.ID] = True
                        antsReached = antsReached+1
                    if a.movingBack == False:
                        a.optimisePath([goalPoint],rectObs,circleObs)
                        a.lastPathFollowed = a.path.copy()                       
                    if recordAnt == None or recordAnt.totalDist>a.totalDist:
                        if recordAnt == None:
                            recordAnt = ant.Ant(antPopnSize+1,a.pos)
                        else:
                            lastBestPath = recordAnt.totalDist
                        recordAnt.pos = int(a.pos[0]),int(a.pos[1])
                        recordAnt.path = a.lastPathFollowed.copy()
                        print('pathfollowed length: ' + str(len(a.path))) #even if same ant btr pth while going back, it gets updated here only
                        #if len(a.path) == 1:
                         #   print(str(a.path[0][0]) + ' ' + str(a.path[0][1]) + ' ' + str(initialPoint[0]) + ' ' + str(initialPoint[1]))
                        recordAnt.totalDist = a.totalDist
                        #velocity,reachedGoal etc not imp                        
                        print('new min path ' + str(recordAnt.totalDist))
                    #in all cases move back after this
                    s = len(a.path)
                    nextPos = a.path[s-1]                   
                    if s == 1:
                        print('reached back, resetting')
                        a.pos = nextPos
                        a.reachedGoal = False
                        a.totalDist = 0
                        a.movingBack = False
                        #a.path = [self.pos] - already true
                    else:
                        #when s==2 we pop, move to path[0] and deposit pher there
                        a.movingBack = True
                        a.path.pop(s-1) #last element removed by default
                        a.pos = a.path[s-2]
                        print('ant move back')
                        a.moveBack(rectObs,circleObs,nextPos,initialPoint,XDIM,YDIM,gridscale,pheromoneTrack)
                else:
                    print('ant move further')
                    a.move(rectObs,circleObs,XDIM,YDIM,pheromoneTrack,gridscale,goalPoint,GOAL_RADIUS)           
            
            if antsReached == antPopnSize:
                print('all ants reached')
                samePath = False
                #if all ants reached, how can lastpathfollowed be none for any -same ant could have reached
                for a in antPopn:
                    for b in antPopn:
                        i=0
                        while i<len(a.lastPathFollowed):
                            if i<len(b.lastPathFollowed) and a.lastPathFollowed[i][0] == b.lastPathFollowed[i][0] and a.lastPathFollowed[i][1] == b.lastPathFollowed[i][1]:
                                samePath = True
                            else:
                                samePath = False
                                break
                            i = i+1
                        if samePath == False:
                            break
                    if samePath == False:
                        break                   
                if samePath == True or antPopnIter>maxAntPopnIter or optimiseIter>=numIter: #if same path, path wont change anymore
                    if samePath == True:
                        print('converged..')
                    if antPopnIter>maxAntPopnIter:
                        print('max iterations reached')
                    if optimiseIter>=numIter:
                        print('no further improvement')
                    currentState = 'pathFound'
                    print('least path found')
                else:
                    if lastBestPath!=0 and (lastBestPath-recordAnt.totalDist)/lastBestPath < minImprovement: #lastbestpath==0 when only 1 min path has been found so far, ie in 1 iteration only 1 best path was found
                        optimiseIter = optimiseIter+1
                    else:
                        optimiseIter=0
                    antsReached = 0
                    antsDone = {}
                    antPopnIter = antPopnIter+1
                    print('antPopnIter = ' + str(antPopnIter))
                    currentState = 'findPath'
        
        elif currentState == 'pathFound': #path found in 2 conditions - if iterations over or if all ants following same path
            return geometry.Edge(v1,v2,recordAnt.path)
        