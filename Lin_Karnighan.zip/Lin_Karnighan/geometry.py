from math import *

def dist(p1,p2):     #distance between two points
   return sqrt((p1[0]-p2[0])*(p1[0]-p2[0])+(p1[1]-p2[1])*(p1[1]-p2[1]))

class Vertex:
    numOfInstance = 0
    def __init__(self, point):        
        self.vId = Vertex.numOfInstance
        Vertex.numOfInstance = Vertex.numOfInstance+1
        self.point = point

class Edge:
    def __init__(self, v1, v2, linkPoints):
        self.v1 = v1
        self.v2 = v2
        self.linkPoints = linkPoints
        
        l=0
        i=0
        while i<len(linkPoints)-1:
            l=l+dist(linkPoints[i],linkPoints[i+1])
            i=i+1       
        self.length = l

class Tour:
    def __init__(self, tour, tourlength):
        self.tour = tour
        #this is a dictionary of vId which points to array of length 2 - the 2 vertice ids it is connected to in order at 0th index is the one before, at 1st is one after
        #self.findAllEdges() - can call from outside also before calling this randomtour fn
        #d=dist(initialPoint,self.vertices[0]) #we need all edges from initial point also
        
        #d=d+edges[str(i)+'-'+'initial'].length #we need all edges from initial point also
        self.tourlength=tourlength
        #self.bestg = 0 #doesnt matter - this wont be best tour anyway